Readme zum Tool AUT_FS_DETAIL

Allgemeines:
Mit dem Tool k�nnen die Fehler- und die Info-Speicher (inkl. den Detail-
Informationen) mehrerer SG's ausgelesen werden.
S�mtliche Informationen werden in den Ausgabe-Sheets abgelegt.

Vorraussetzung:
Excel 2000 oder h�her

Eingabe:
Im Sheet EINGABE (in Spalte A) werden die zu pr�fenden SGBDen
angegeben. 
Die SGBDen k�nnen entweder manuell eingegeben werden, oder
automatisch per Ident_Funktional (Button "Ident funkt."). Die per
Ident_Funktional ermittelten SGBDen werden zus�tzlich zu den bereits
vorhandeen SGBDen in das Sheet eingetragen (allerdings werden keine
doppelten Eintr�ge vorgenommen).

Ausgabe:
Die Daten des FS_LESEN befinden sich in AUSGABE_FS , die Daten von 
IS_LESEN in AUSGABE_IS und die Ident-Daten im Sheet IDENT
Durch den Button "Start FS" wird das Sheet (bzw. Sheets) bef�llt. Es werden
nur die Fehlerspeicher, der im Sheet Eingabe eingetragenen SGBDen
ermittelt. Der bisherige Inhalt des Sheets wird gel�scht.

IDENT
Wird Ident_Funktional (Button  "Ident funkt.") ausgef�hrt, wird
dieses Sheet mit den Ident-Daten aller antwortenden SGBDen bef�llt. Der
bisherige Inhalt des Sheets wird gel�scht.

TRACES
Zu jedem Testlauf wird der IFH- und der API-Trace
abgespeichert. Der Name der Trace-Datei wird aus dem Namen der
Excel-Datei, aktuelles Datum und Uhrzeit gebildet.


Bei Fragen und Problemen wenden Sie sich bitte an:
Rainer Gramer TI-430
089 / 382 40612
rainer.gramer@bmw.de
