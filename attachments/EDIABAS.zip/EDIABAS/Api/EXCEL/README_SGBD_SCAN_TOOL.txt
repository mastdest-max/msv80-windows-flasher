Readme zum SCAN-TOOL

Das Tool dient zum Auslesen des Inhalts einer SGBD.
Die Ergebnisse k�nnen in den SGBD-Checker �bernommen werden.

Bei Fragen und Problemen wenden Sie sich bitte an:
Rainer Gramer TI-430
089 / 382 40612
rainer.gramer@bmw.de
