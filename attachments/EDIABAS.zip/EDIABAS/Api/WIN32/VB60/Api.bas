'///
'///    api.bas
'///
'///    Comment       Visual Basic 6.0 Interface of EDIABAS for Win32
'///
'////////////////////////////////////////////////////////////////////////////////
Option Explicit


' Types:

' VB Type of APIBOOL = Integer
' VB Type of APICHAR = Byte
' VB Type of APIBYTE = Byte
' VB Type of APIINTEGER = Integer
' VB Type of APIWORD = Integer
' VB Type of APILONG = Long
' VB Type of APIDWORD = Long
' VB Type of APITEXT[] = String
' VB Type of APIBINARY[] = Array of Byte
' VB Type of APIREAL = Double
' VB Type of APIRESULTFIELD = Long


' Procedures and functions:

' Function apiCheckVersion (ByVal versionCompatibility&,versionInfo$) as Integer
' Function apiInit As Integer
' Function apiInitExt (ByVal device$, ByVal devConnection$, ByVal devApplication$, ByVal reserved$) As Integer
' Sub apiEnd
' Function apiSwitchDevice (ByVal deviceConnection$, ByVal deviceApplication$) As Integer
' Sub apiJob (ByVal ecu$, ByVal job$, ByVal para$, ByVal result$)
' Sub apiJobData (ByVal ecu$, ByVal job$, parabuf as byte, ByVal paralen%, ByVal result$)
' Sub apiJobExt (ByVal ecu$, ByVal job$, stdparabuf as byte, ByVal stdparalen%, parabuf as byte, ByVal paralen%, ByVal result$, ByVal reserved&)
' Function apiJobInfo (infoText$) as Integer
' Function apiResultChar (buf as byte, ByVal result$, ByVal setnr%) As Integer
' Function apiResultByte (buf as byte, ByVal result$, ByVal setnr%) As Integer
' Function apiResultInt (buf%, ByVal result$, ByVal setnr%) As Integer
' Function apiResultWord (buf%, ByVal result$, ByVal setnr%) As Integer
' Function apiResultLong (buf&, ByVal result$, ByVal setnr%) As Integer
' Function apiResultDWord (buf&, ByVal result$, ByVal setnr%) As Integer
' Function apiResultReal (buf#, ByVal result$, ByVal setnr%) As Integer
' Function apiResultText (buf$, ByVal result$, ByVal setnr%, ByVal formatspec$) As Integer
' Function apiResultBinary (buf as byte, buflen%, ByVal result$, ByVal setnr%) As Integer
' Function apiResultBinaryExt (buf as byte, buflen&, ByVal bufsize&, ByVal result$, ByVal setnr%) As Integer
' Function apiResultFormat (buf%, ByVal result$, ByVal setnr%) As Integer
' Function apiResultNumber (buf%, ByVal setnr%) As Integer
' Function apiResultName (buf$, ByVal index%, ByVal setnr%) As Integer
' Function apiResultSets (sets%) As Integer
' Function apiResultVar (ecu$) As Integer
' Function apiResultsNew As Long
' Sub apiResultsScope (ByVal field&)
' Sub apiResultsDelete (ByVal field&)
' Function apiState As Integer
' Function apiStateExt As Integer
' Sub apiBreak
' Function apiErrorCode As Integer
' Function apiErrorText As String
' Function apiSetConfig (ByVal configName$, ByVal configValue$) As Integer
' Function apiGetConfig (ByVal configName$, configValue$) As Integer
' Sub apiTrace (ByVal msg$)

' Sub closeServer
' Function enableServer (ByVal onOff As Boolean) As Boolean
' Function enableMultiThreading (ByVal onOff As Boolean) As Boolean

' NOT supported procedures and functions:
'          apiErrorHandler
'          apiCallBack

' Constants:

Global Const APICOMPATIBILITYVERSION = &H0700	' API compatibility version

Global Const APIBUSY_ = 0                   ' suffix _ because of name conflict
Global Const APIREADY_ = 1                  ' suffix _ because of name conflict
Global Const APIBREAK_ = 2                  ' suffix _ because of name conflict
Global Const APIERROR_ = 3                  ' suffix _ because of name conflict

Global Const APIMAXDEVICE = 64              ' maximal device (connection, application)
Global Const APIMAXNAME = 64                ' maximal name length (job, ecu, result)
Global Const APIMAXSTDPARA = 256            ' maximal standard job para length
Global Const APIMAXPARA = 1024              ' maximal job para length
Global Const APIMAXPARAEXT = 65536          ' maximal job para binary length / v7
Global Const APIMAXRESULT = 256             ' maximal result length

Global Const APIMAXTEXT = 1024              ' maximal text length
Global Const APIMAXBINARY = 1024            ' maximal binary buffer length
Global Const APIMAXBINARYEXT = 65536        ' maximal binary buffer length / v7

Global Const APIMAXCONFIG = 256             ' maximal config buffer length

Global Const APIMAXFILENAME = 256           ' maximal filename length

Global Const APITRUE = 1
Global Const APIFALSE = 0

Global Const APIFORMAT_CHAR = 0             ' CHAR format
Global Const APIFORMAT_BYTE = 1             ' BYTE format
Global Const APIFORMAT_INTEGER = 2          ' INTEGER format
Global Const APIFORMAT_WORD = 3             ' WORD format
Global Const APIFORMAT_LONG = 4             ' LONG format
Global Const APIFORMAT_DWORD = 5            ' DWORD format
Global Const APIFORMAT_TEXT = 6             ' TEXT format
Global Const APIFORMAT_BINARY = 7           ' BINARY format
Global Const APIFORMAT_REAL = 8             ' REAL format

' API error codes:
Global Const EDIABAS_ERR_NONE = 0
Global Const EDIABAS_RESERVED = 1
Global Const EDIABAS_ERROR_CODE_OUT_OF_RANGE = 2

Global Const EDIABAS_IFH_0000 = 10
Global Const EDIABAS_IFH_0001 = 11
Global Const EDIABAS_IFH_0002 = 12
Global Const EDIABAS_IFH_0003 = 13
Global Const EDIABAS_IFH_0004 = 14
Global Const EDIABAS_IFH_0005 = 15
Global Const EDIABAS_IFH_0006 = 16
Global Const EDIABAS_IFH_0007 = 17
Global Const EDIABAS_IFH_0008 = 18
Global Const EDIABAS_IFH_0009 = 19
Global Const EDIABAS_IFH_0010 = 20
Global Const EDIABAS_IFH_0011 = 21
Global Const EDIABAS_IFH_0012 = 22
Global Const EDIABAS_IFH_0013 = 23
Global Const EDIABAS_IFH_0014 = 24
Global Const EDIABAS_IFH_0015 = 25
Global Const EDIABAS_IFH_0016 = 26
Global Const EDIABAS_IFH_0017 = 27
Global Const EDIABAS_IFH_0018 = 28
Global Const EDIABAS_IFH_0019 = 29
Global Const EDIABAS_IFH_0020 = 30
Global Const EDIABAS_IFH_0021 = 31
Global Const EDIABAS_IFH_0022 = 32
Global Const EDIABAS_IFH_0023 = 33
Global Const EDIABAS_IFH_0024 = 34
Global Const EDIABAS_IFH_0025 = 35
Global Const EDIABAS_IFH_0026 = 36
Global Const EDIABAS_IFH_0027 = 37
Global Const EDIABAS_IFH_0028 = 38
Global Const EDIABAS_IFH_0029 = 39
Global Const EDIABAS_IFH_0030 = 40
Global Const EDIABAS_IFH_0031 = 41
Global Const EDIABAS_IFH_0032 = 42
Global Const EDIABAS_IFH_0033 = 43
Global Const EDIABAS_IFH_0034 = 44
Global Const EDIABAS_IFH_0035 = 45
Global Const EDIABAS_IFH_0036 = 46
Global Const EDIABAS_IFH_0037 = 47
Global Const EDIABAS_IFH_0038 = 48
Global Const EDIABAS_IFH_0039 = 49
Global Const EDIABAS_IFH_0040 = 50
Global Const EDIABAS_IFH_0041 = 51
Global Const EDIABAS_IFH_0042 = 52
Global Const EDIABAS_IFH_0043 = 53
Global Const EDIABAS_IFH_0044 = 54
Global Const EDIABAS_IFH_0045 = 55
Global Const EDIABAS_IFH_0046 = 56
Global Const EDIABAS_IFH_0047 = 57
Global Const EDIABAS_IFH_0048 = 58
Global Const EDIABAS_IFH_0049 = 59
Global Const EDIABAS_IFH_LAST = 59

Global Const EDIABAS_BIP_0000 = 60
Global Const EDIABAS_BIP_0001 = 61
Global Const EDIABAS_BIP_0002 = 62
Global Const EDIABAS_BIP_0003 = 63
Global Const EDIABAS_BIP_0004 = 64
Global Const EDIABAS_BIP_0005 = 65
Global Const EDIABAS_BIP_0006 = 66
Global Const EDIABAS_BIP_0007 = 67
Global Const EDIABAS_BIP_0008 = 68
Global Const EDIABAS_BIP_0009 = 69
Global Const EDIABAS_BIP_0010 = 70
Global Const EDIABAS_BIP_0011 = 71
Global Const EDIABAS_BIP_0012 = 72
Global Const EDIABAS_BIP_0013 = 73
Global Const EDIABAS_BIP_0014 = 74
Global Const EDIABAS_BIP_0015 = 75
Global Const EDIABAS_BIP_0016 = 76
Global Const EDIABAS_BIP_0017 = 77
Global Const EDIABAS_BIP_0018 = 78
Global Const EDIABAS_BIP_0019 = 79
Global Const EDIABAS_BIP_0020 = 80
Global Const EDIABAS_BIP_0021 = 81
Global Const EDIABAS_BIP_0022 = 82
Global Const EDIABAS_BIP_0023 = 83
Global Const EDIABAS_BIP_0024 = 84
Global Const EDIABAS_BIP_0025 = 85
Global Const EDIABAS_BIP_0026 = 86
Global Const EDIABAS_BIP_0027 = 87
Global Const EDIABAS_BIP_0028 = 88
Global Const EDIABAS_BIP_0029 = 89
Global Const EDIABAS_BIP_LAST = 89

Global Const EDIABAS_SYS_0000 = 90
Global Const EDIABAS_SYS_0001 = 91
Global Const EDIABAS_SYS_0002 = 92
Global Const EDIABAS_SYS_0003 = 93
Global Const EDIABAS_SYS_0004 = 94
Global Const EDIABAS_SYS_0005 = 95
Global Const EDIABAS_SYS_0006 = 96
Global Const EDIABAS_SYS_0007 = 97
Global Const EDIABAS_SYS_0008 = 98
Global Const EDIABAS_SYS_0009 = 99
Global Const EDIABAS_SYS_0010 = 100
Global Const EDIABAS_SYS_0011 = 101
Global Const EDIABAS_SYS_0012 = 102
Global Const EDIABAS_SYS_0013 = 103
Global Const EDIABAS_SYS_0014 = 104
Global Const EDIABAS_SYS_0015 = 105
Global Const EDIABAS_SYS_0016 = 106
Global Const EDIABAS_SYS_0017 = 107
Global Const EDIABAS_SYS_0018 = 108
Global Const EDIABAS_SYS_0019 = 109
Global Const EDIABAS_SYS_0020 = 110
Global Const EDIABAS_SYS_0021 = 111
Global Const EDIABAS_SYS_0022 = 112
Global Const EDIABAS_SYS_0023 = 113
Global Const EDIABAS_SYS_0024 = 114
Global Const EDIABAS_SYS_0025 = 115
Global Const EDIABAS_SYS_0026 = 116
Global Const EDIABAS_SYS_0027 = 117
Global Const EDIABAS_SYS_0028 = 118
Global Const EDIABAS_SYS_0029 = 119
Global Const EDIABAS_SYS_LAST = 119

Global Const EDIABAS_API_0000 = 120
Global Const EDIABAS_API_0001 = 121
Global Const EDIABAS_API_0002 = 122
Global Const EDIABAS_API_0003 = 123
Global Const EDIABAS_API_0004 = 124
Global Const EDIABAS_API_0005 = 125
Global Const EDIABAS_API_0006 = 126
Global Const EDIABAS_API_0007 = 127
Global Const EDIABAS_API_0008 = 128
Global Const EDIABAS_API_0009 = 129
Global Const EDIABAS_API_0010 = 130
Global Const EDIABAS_API_0011 = 131
Global Const EDIABAS_API_0012 = 132
Global Const EDIABAS_API_0013 = 133
Global Const EDIABAS_API_0014 = 134
Global Const EDIABAS_API_0015 = 135
Global Const EDIABAS_API_0016 = 136
Global Const EDIABAS_API_0017 = 137
Global Const EDIABAS_API_0018 = 138
Global Const EDIABAS_API_0019 = 139
Global Const EDIABAS_API_0020 = 140
Global Const EDIABAS_API_0021 = 141
Global Const EDIABAS_API_0022 = 142
Global Const EDIABAS_API_0023 = 143
Global Const EDIABAS_API_0024 = 144
Global Const EDIABAS_API_0025 = 145
Global Const EDIABAS_API_0026 = 146
Global Const EDIABAS_API_0027 = 147
Global Const EDIABAS_API_0028 = 148
Global Const EDIABAS_API_0029 = 149
Global Const EDIABAS_API_LAST = 149

Global Const EDIABAS_NET_0000 = 150
Global Const EDIABAS_NET_0001 = 151
Global Const EDIABAS_NET_0002 = 152
Global Const EDIABAS_NET_0003 = 153
Global Const EDIABAS_NET_0004 = 154
Global Const EDIABAS_NET_0005 = 155
Global Const EDIABAS_NET_0006 = 156
Global Const EDIABAS_NET_0007 = 157
Global Const EDIABAS_NET_0008 = 158
Global Const EDIABAS_NET_0009 = 159
Global Const EDIABAS_NET_0010 = 160
Global Const EDIABAS_NET_0011 = 161
Global Const EDIABAS_NET_0012 = 162
Global Const EDIABAS_NET_0013 = 163
Global Const EDIABAS_NET_0014 = 164
Global Const EDIABAS_NET_0015 = 165
Global Const EDIABAS_NET_0016 = 166
Global Const EDIABAS_NET_0017 = 167
Global Const EDIABAS_NET_0018 = 168
Global Const EDIABAS_NET_0019 = 169
Global Const EDIABAS_NET_0020 = 170
Global Const EDIABAS_NET_0021 = 171
Global Const EDIABAS_NET_0022 = 172
Global Const EDIABAS_NET_0023 = 173
Global Const EDIABAS_NET_0024 = 174
Global Const EDIABAS_NET_0025 = 175
Global Const EDIABAS_NET_0026 = 176
Global Const EDIABAS_NET_0027 = 177
Global Const EDIABAS_NET_0028 = 178
Global Const EDIABAS_NET_0029 = 179
Global Const EDIABAS_NET_0030 = 180
Global Const EDIABAS_NET_0031 = 181
Global Const EDIABAS_NET_0032 = 182
Global Const EDIABAS_NET_0033 = 183
Global Const EDIABAS_NET_0034 = 184
Global Const EDIABAS_NET_0035 = 185
Global Const EDIABAS_NET_0036 = 186
Global Const EDIABAS_NET_0037 = 187
Global Const EDIABAS_NET_0038 = 188
Global Const EDIABAS_NET_0039 = 189
Global Const EDIABAS_NET_0040 = 190
Global Const EDIABAS_NET_0041 = 191
Global Const EDIABAS_NET_0042 = 192
Global Const EDIABAS_NET_0043 = 193
Global Const EDIABAS_NET_0044 = 194
Global Const EDIABAS_NET_0045 = 195
Global Const EDIABAS_NET_0046 = 196
Global Const EDIABAS_NET_0047 = 197
Global Const EDIABAS_NET_0048 = 198
Global Const EDIABAS_NET_0049 = 199
Global Const EDIABAS_NET_LAST = 199

Global Const EDIABAS_IFH_0050 = 200
Global Const EDIABAS_IFH_0051 = 201
Global Const EDIABAS_IFH_0052 = 202
Global Const EDIABAS_IFH_0053 = 203
Global Const EDIABAS_IFH_0054 = 204
Global Const EDIABAS_IFH_0055 = 205
Global Const EDIABAS_IFH_0056 = 206
Global Const EDIABAS_IFH_0057 = 207
Global Const EDIABAS_IFH_0058 = 208
Global Const EDIABAS_IFH_0059 = 209
Global Const EDIABAS_IFH_0060 = 210
Global Const EDIABAS_IFH_0061 = 211
Global Const EDIABAS_IFH_0062 = 212
Global Const EDIABAS_IFH_0063 = 213
Global Const EDIABAS_IFH_0064 = 214
Global Const EDIABAS_IFH_0065 = 215
Global Const EDIABAS_IFH_0066 = 216
Global Const EDIABAS_IFH_0067 = 217
Global Const EDIABAS_IFH_0068 = 218
Global Const EDIABAS_IFH_0069 = 219
Global Const EDIABAS_IFH_0070 = 220
Global Const EDIABAS_IFH_0071 = 221
Global Const EDIABAS_IFH_0072 = 222
Global Const EDIABAS_IFH_0073 = 223
Global Const EDIABAS_IFH_0074 = 224
Global Const EDIABAS_IFH_0075 = 225
Global Const EDIABAS_IFH_0076 = 226
Global Const EDIABAS_IFH_0077 = 227
Global Const EDIABAS_IFH_0078 = 228
Global Const EDIABAS_IFH_0079 = 229
Global Const EDIABAS_IFH_0080 = 230
Global Const EDIABAS_IFH_0081 = 231
Global Const EDIABAS_IFH_0082 = 232
Global Const EDIABAS_IFH_0083 = 233
Global Const EDIABAS_IFH_0084 = 234
Global Const EDIABAS_IFH_0085 = 235
Global Const EDIABAS_IFH_0086 = 236
Global Const EDIABAS_IFH_0087 = 237
Global Const EDIABAS_IFH_0088 = 238
Global Const EDIABAS_IFH_0089 = 239
Global Const EDIABAS_IFH_0090 = 240
Global Const EDIABAS_IFH_0091 = 241
Global Const EDIABAS_IFH_0092 = 242
Global Const EDIABAS_IFH_0093 = 243
Global Const EDIABAS_IFH_0094 = 244
Global Const EDIABAS_IFH_0095 = 245
Global Const EDIABAS_IFH_0096 = 246
Global Const EDIABAS_IFH_0097 = 247
Global Const EDIABAS_IFH_0098 = 248
Global Const EDIABAS_IFH_0099 = 249
Global Const EDIABAS_IFH_LAST2 = 249

Global Const EDIABAS_RUN_0000 = 250
Global Const EDIABAS_RUN_0001 = 251
Global Const EDIABAS_RUN_0002 = 252
Global Const EDIABAS_RUN_0003 = 253
Global Const EDIABAS_RUN_0004 = 254
Global Const EDIABAS_RUN_0005 = 255
Global Const EDIABAS_RUN_0006 = 256
Global Const EDIABAS_RUN_0007 = 257
Global Const EDIABAS_RUN_0008 = 258
Global Const EDIABAS_RUN_0009 = 259
Global Const EDIABAS_RUN_0010 = 260
Global Const EDIABAS_RUN_0011 = 261
Global Const EDIABAS_RUN_0012 = 262
Global Const EDIABAS_RUN_0013 = 263
Global Const EDIABAS_RUN_0014 = 264
Global Const EDIABAS_RUN_0015 = 265
Global Const EDIABAS_RUN_0016 = 266
Global Const EDIABAS_RUN_0017 = 267
Global Const EDIABAS_RUN_0018 = 268
Global Const EDIABAS_RUN_0019 = 269
Global Const EDIABAS_RUN_0020 = 270
Global Const EDIABAS_RUN_0021 = 271
Global Const EDIABAS_RUN_0022 = 272
Global Const EDIABAS_RUN_0023 = 273
Global Const EDIABAS_RUN_0024 = 274
Global Const EDIABAS_RUN_0025 = 275
Global Const EDIABAS_RUN_0026 = 276
Global Const EDIABAS_RUN_0027 = 277
Global Const EDIABAS_RUN_0028 = 278
Global Const EDIABAS_RUN_0029 = 279
Global Const EDIABAS_RUN_0030 = 280
Global Const EDIABAS_RUN_0031 = 281
Global Const EDIABAS_RUN_0032 = 282
Global Const EDIABAS_RUN_0033 = 283
Global Const EDIABAS_RUN_0034 = 284
Global Const EDIABAS_RUN_0035 = 285
Global Const EDIABAS_RUN_0036 = 286
Global Const EDIABAS_RUN_0037 = 287
Global Const EDIABAS_RUN_0038 = 288
Global Const EDIABAS_RUN_0039 = 289
Global Const EDIABAS_RUN_0040 = 290
Global Const EDIABAS_RUN_0041 = 291
Global Const EDIABAS_RUN_0042 = 292
Global Const EDIABAS_RUN_0043 = 293
Global Const EDIABAS_RUN_0044 = 294
Global Const EDIABAS_RUN_0045 = 295
Global Const EDIABAS_RUN_0046 = 296
Global Const EDIABAS_RUN_0047 = 297
Global Const EDIABAS_RUN_0048 = 298
Global Const EDIABAS_RUN_0049 = 299
Global Const EDIABAS_RUN_0050 = 300
Global Const EDIABAS_RUN_0051 = 301
Global Const EDIABAS_RUN_0052 = 302
Global Const EDIABAS_RUN_0053 = 303
Global Const EDIABAS_RUN_0054 = 304
Global Const EDIABAS_RUN_0055 = 305
Global Const EDIABAS_RUN_0056 = 306
Global Const EDIABAS_RUN_0057 = 307
Global Const EDIABAS_RUN_0058 = 308
Global Const EDIABAS_RUN_0059 = 309
Global Const EDIABAS_RUN_0060 = 310
Global Const EDIABAS_RUN_0061 = 311
Global Const EDIABAS_RUN_0062 = 312
Global Const EDIABAS_RUN_0063 = 313
Global Const EDIABAS_RUN_0064 = 314
Global Const EDIABAS_RUN_0065 = 315
Global Const EDIABAS_RUN_0066 = 316
Global Const EDIABAS_RUN_0067 = 317
Global Const EDIABAS_RUN_0068 = 318
Global Const EDIABAS_RUN_0069 = 319
Global Const EDIABAS_RUN_0070 = 320
Global Const EDIABAS_RUN_0071 = 321
Global Const EDIABAS_RUN_0072 = 322
Global Const EDIABAS_RUN_0073 = 323
Global Const EDIABAS_RUN_0074 = 324
Global Const EDIABAS_RUN_0075 = 325
Global Const EDIABAS_RUN_0076 = 326
Global Const EDIABAS_RUN_0077 = 327
Global Const EDIABAS_RUN_0078 = 328
Global Const EDIABAS_RUN_0079 = 329
Global Const EDIABAS_RUN_0080 = 330
Global Const EDIABAS_RUN_0081 = 331
Global Const EDIABAS_RUN_0082 = 332
Global Const EDIABAS_RUN_0083 = 333
Global Const EDIABAS_RUN_0084 = 334
Global Const EDIABAS_RUN_0085 = 335
Global Const EDIABAS_RUN_0086 = 336
Global Const EDIABAS_RUN_0087 = 337
Global Const EDIABAS_RUN_0088 = 338
Global Const EDIABAS_RUN_0089 = 339
Global Const EDIABAS_RUN_0090 = 340
Global Const EDIABAS_RUN_0091 = 341
Global Const EDIABAS_RUN_0092 = 342
Global Const EDIABAS_RUN_0093 = 343
Global Const EDIABAS_RUN_0094 = 344
Global Const EDIABAS_RUN_0095 = 345
Global Const EDIABAS_RUN_0096 = 346
Global Const EDIABAS_RUN_0097 = 347
Global Const EDIABAS_RUN_0098 = 348
Global Const EDIABAS_RUN_0099 = 349
Global Const EDIABAS_RUN_LAST = 349

Global Const EDIABAS_ERROR_LAST = 349


' --------------------------------------------------------------------
' Internal data
' --------------------------------------------------------------------
' DLL handle
Dim dllHandle&

' --------------------------------------------------------------------------------
' Internal helper functions of APIVB32.DLL (don't call these functions!)
' --------------------------------------------------------------------------------
Declare Function apiVB4CheckVersion Lib "apivb32.dll" (ByVal versionCompatibility&, ByVal infoText$, infolen%) As Integer
Declare Function apiVBInit Lib "apivb32.dll" (handle&) As Integer
Declare Function apiVBInitExt Lib "apivb32.dll" (handle&, ByVal device$, ByVal devConnection$, ByVal devApplication$, ByVal reserved$) As Integer
Declare Sub apiVBEnd Lib "apivb32.dll" (ByVal handle&)
Declare Function apiVBSwitchDevice Lib "apivb32.dll" (ByVal handle&, ByVal deviceConnection$, ByVal deviceApplication$) As Integer
Declare Sub apiVBJob Lib "apivb32.dll" (ByVal handle&, ByVal ecu$, ByVal job$, ByVal para$, ByVal result$)
Declare Sub apiVB4JobData Lib "apivb32.dll" (ByVal handle&, ByVal ecu$, ByVal job$, parabuf As Byte, ByVal paralen%, ByVal result$)
Declare Sub apiVB4JobExt Lib "apivb32.dll" (ByVal handle&, ByVal ecu$, ByVal job$, stdparabuf As Byte, ByVal stdparalen%, parabuf As Byte, ByVal paralen%, ByVal result$, ByVal reserved&)
Declare Function apiVB4JobInfo Lib "apivb32.dll" (ByVal handle&, ByVal infoText$, infolen%) As Integer
Declare Function apiVBResultChar Lib "apivb32.dll" (ByVal handle&, buf As Byte, ByVal result$, ByVal setnr%) As Integer
Declare Function apiVBResultByte Lib "apivb32.dll" (ByVal handle&, buf As Byte, ByVal result$, ByVal setnr%) As Integer
Declare Function apiVBResultInt Lib "apivb32.dll" (ByVal handle&, buf%, ByVal result$, ByVal setnr%) As Integer
Declare Function apiVBResultWord Lib "apivb32.dll" (ByVal handle&, buf%, ByVal result$, ByVal setnr%) As Integer
Declare Function apiVBResultLong Lib "apivb32.dll" (ByVal handle&, buf&, ByVal result$, ByVal setnr%) As Integer
Declare Function apiVBResultDWord Lib "apivb32.dll" (ByVal handle&, buf&, ByVal result$, ByVal setnr%) As Integer
Declare Function apiVBResultReal Lib "apivb32.dll" (ByVal handle&, buf#, ByVal result$, ByVal setnr%) As Integer
Declare Function apiVB4ResultText Lib "apivb32.dll" (ByVal handle&, ByVal buf$, buflen%, ByVal result$, ByVal setnr%, ByVal formatspec$) As Integer
Declare Function apiVB4ResultBinary Lib "apivb32.dll" (ByVal handle&, buf As Byte, buflen%, ByVal result$, ByVal setnr%) As Integer
Declare Function apiVB4ResultBinaryExt Lib "apivb32.dll" (ByVal handle&, buf As Byte, buflen&, ByVal bufsize&, ByVal result$, ByVal setnr%) As Integer
Declare Function apiVBResultFormat Lib "apivb32.dll" (ByVal handle&, buf%, ByVal result$, ByVal setnr%) As Integer
Declare Function apiVBResultNumber Lib "apivb32.dll" (ByVal handle&, buf%, ByVal setnr%) As Integer
Declare Function apiVB4ResultName Lib "apivb32.dll" (ByVal handle&, ByVal buf$, buflen%, ByVal index%, ByVal setnr%) As Integer
Declare Function apiVBResultSets Lib "apivb32.dll" (ByVal handle&, sets%) As Integer
Declare Function apiVB4ResultVar Lib "apivb32.dll" (ByVal handle&, ByVal ecu$, eculen%) As Integer
Declare Function apiVBResultsNew Lib "apivb32.dll" (ByVal handle&) As Long
Declare Sub apiVBResultsScope Lib "apivb32.dll" (ByVal handle&, ByVal field&)
Declare Sub apiVBResultsDelete Lib "apivb32.dll" (ByVal handle&, ByVal field&)
Declare Function apiVBState Lib "apivb32.dll" (ByVal handle&) As Integer
Declare Function apiVBStateExt Lib "apivb32.dll" (ByVal handle&, ByVal ms&) As Integer
Declare Sub apiVBBreak Lib "apivb32.dll" (ByVal handle&)
Declare Function apiVBErrorCode Lib "apivb32.dll" (ByVal handle&) As Integer
Declare Sub apiVB4ErrorText Lib "apivb32.dll" (ByVal handle&, ByVal errortext$, errorlen%)
Declare Function apiVBSetConfig Lib "apivb32.dll" (ByVal handle&, ByVal configName$, ByVal configValue$) As Integer
Declare Function apiVB4GetConfig Lib "apivb32.dll" (ByVal handle&, ByVal configName$, ByVal configValue$, configlen%) As Integer
Declare Sub apiVBTrace Lib "apivb32.dll" (ByVal handle&, ByVal msg$)
Declare Sub closeServerVB Lib "apivb32.dll" ()
Declare Function enableServerVB Lib "apivb32.dll" (ByVal onOff%) As Integer
Declare Function enableMultiThreadingVB Lib "apivb32.dll" (ByVal onOff%) As Integer

Sub apiBreak()
    Call apiVBBreak(dllHandle)
End Sub

Function apiCheckVersion(ByVal versionCompatibility&,versionInfo$) As Integer
    Dim tmpInfo As String * APIMAXCONFIG
    Dim n%
    apiCheckVersion = apiVB4CheckVersion(versionCompatibility, tmpInfo, n)
    If n > 0 Then
        versionInfo = Left(tmpInfo, n)
    End If
End Function

Sub apiEnd()
    Call apiVBEnd(dllHandle)
End Sub

Function apiErrorCode() As Integer
    apiErrorCode = apiVBErrorCode(dllHandle)
End Function

Function apiErrorText() As String
    Dim tmpErrorText As String * 256
    Dim n%
    Call apiVB4ErrorText(dllHandle, tmpErrorText, n)
    apiErrorText = Left(tmpErrorText, n)
End Function

Function apiGetConfig(ByVal configName$, configValue$) As Integer
    Dim tmpConfigvalue As String * APIMAXCONFIG
    Dim n%
    apiGetConfig = apiVB4GetConfig(dllHandle, configName, tmpConfigvalue, n)
    configValue = Left(tmpConfigvalue, n)
End Function

Function apiInit() As Integer
    apiInit = apiVBInit(dllHandle)
End Function

Function apiInitExt(ByVal device$, ByVal devConnection$, ByVal devApplication$, ByVal reserved$) As Integer
    apiInitExt = apiVBInitExt(dllHandle, device, devConnection, devApplication, reserved)
End Function

Sub apiJob(ByVal ecu$, ByVal job$, ByVal para$, ByVal result$)

    If Len(ecu) = 0 Then
        ecu = ""        ' necessary because of VB bug
    End If
    If Len(job) = 0 Then
        job = ""        ' necessary because of VB bug
    End If
    If Len(para) = 0 Then
        para = ""       ' necessary because of VB bug
    End If
    If Len(result) = 0 Then
        result = ""     ' necessary because of VB bug
    End If
    Call apiVBJob(dllHandle, ecu, job, para, result)
End Sub

Sub apiJobData(ByVal ecu$, ByVal job$, parabuf As Byte, ByVal paralen%, ByVal result$)
    ' "parabuf" is the reference on a byte array (base 0) with at least the length of "paralen"
    If Len(ecu) = 0 Then
        ecu = ""        ' necessary because of VB bug
    End If
    If Len(job) = 0 Then
        job = ""        ' necessary because of VB bug
    End If
    If Len(result) = 0 Then
        result = ""     ' necessary because of VB bug
    End If
    Call apiVB4JobData(dllHandle, ecu, job, parabuf, paralen, result)
End Sub

Sub apiJobExt(ByVal ecu$, ByVal job$, stdparabuf As Byte, ByVal stdparalen%, parabuf As Byte, ByVal paralen%, ByVal result$, ByVal reserved&)
    ' "stdparabuf"/"parabuf" are the reference on byte array (base 0) with at least the length of "stdparalen"/"paralen"
    If Len(ecu) = 0 Then
        ecu = ""        ' necessary because of VB bug
    End If
    If Len(job) = 0 Then
        job = ""        ' necessary because of VB bug
    End If
    If Len(result) = 0 Then
        result = ""     ' necessary because of VB bug
    End If
    Call apiVB4JobExt(dllHandle, ecu, job, stdparabuf, stdparalen, parabuf, paralen, result, reserved)
End Sub

Function apiJobInfo(reserved$) As Integer
    Dim tmpInfo As String * APIMAXTEXT
    Dim n%
    apiJobInfo = apiVB4JobInfo(dllHandle, tmpInfo, n)
    If n > 0 Then
        reserved = Left(tmpInfo, n)
    End If
End Function

Function apiResultBinary(buf As Byte, buflen%, ByVal result$, ByVal setnr%) As Integer
    ' "buf" is the reference on a array of byte (base 0) with the length of at least APIMAXBINARY
    apiResultBinary = apiVB4ResultBinary(dllHandle, buf, buflen, result, setnr)
    ' VB4 error (LeftB()): buffer resizing not possible
    ' If buflen > 0 Then
    '    buf = LeftB(buf, buflen)
    ' End If
End Function

Function apiResultBinaryExt(buf As Byte, buflen&, ByVal bufsize&, ByVal result$, ByVal setnr%) As Integer
    ' "buf" is the reference on a array of byte (base 0) with the length of at least APIMAXBINARYEXT
    apiResultBinaryExt = apiVB4ResultBinaryExt(dllHandle, buf, buflen, bufsize, result, setnr)
    ' VB4 error (LeftB()): buffer resizing not possible
    ' If buflen > 0 Then
    '    buf = LeftB(buf, buflen)
    ' End If
End Function

Function apiResultDWord(buf&, ByVal result$, ByVal setnr%) As Integer
    apiResultDWord = apiVBResultDWord(dllHandle, buf, result, setnr)
End Function

Function apiResultFormat(buf%, ByVal result$, ByVal setnr%) As Integer
    apiResultFormat = apiVBResultFormat(dllHandle, buf, result, setnr)
End Function

Function apiResultChar(buf As Byte, ByVal result$, ByVal setnr%) As Integer
    apiResultChar = apiVBResultChar(dllHandle, buf, result, setnr)
End Function
Function apiResultInt(buf%, ByVal result$, ByVal setnr%) As Integer
    apiResultInt = apiVBResultInt(dllHandle, buf, result, setnr)
End Function

Function apiResultLong(buf&, ByVal result$, ByVal setnr%) As Integer
    apiResultLong = apiVBResultLong(dllHandle, buf, result, setnr)
End Function

Function apiResultName(buf$, ByVal index%, ByVal setnr%) As Integer
    Dim tmpName As String * APIMAXNAME
    Dim n%
    apiResultName = apiVB4ResultName(dllHandle, tmpName, n, index, setnr)
    buf = Left(tmpName, n)
End Function

Function apiResultNumber(buf%, ByVal setnr%) As Integer
    apiResultNumber = apiVBResultNumber(dllHandle, buf, setnr)
End Function

Function apiResultReal(buf#, ByVal result$, ByVal setnr%) As Integer
    apiResultReal = apiVBResultReal(dllHandle, buf, result, setnr)
End Function

Sub apiResultsDelete(ByVal field&)
    Call apiVBResultsDelete(dllHandle, field)
End Sub

Function apiResultSets(sets%) As Integer
    apiResultSets = apiVBResultSets(dllHandle, sets)
End Function

Function apiResultsNew() As Long
    apiResultsNew = apiVBResultsNew(dllHandle)
End Function

Sub apiResultsScope(ByVal field&)
    Call apiVBResultsScope(dllHandle, field)
End Sub

Function apiResultText(buf$, ByVal result$, ByVal setnr%, ByVal formatspec$) As Integer
    Dim tmpText As String * APIMAXTEXT
    Dim n%
    apiResultText = apiVB4ResultText(dllHandle, tmpText, n, result, setnr, formatspec)
    buf = Left(tmpText, n)
End Function

Function apiResultVar(ecu$) As Integer
    Dim tmpEcu As String * APIMAXNAME
    Dim n%
    apiResultVar = apiVB4ResultVar(dllHandle, tmpEcu, n)
    ecu = Left(tmpEcu, n)
End Function

Function apiResultWord(buf%, ByVal result$, ByVal setnr%) As Integer
    apiResultWord = apiVBResultWord(dllHandle, buf, result, setnr)
End Function
Function apiResultByte(buf As Byte, ByVal result$, ByVal setnr%) As Integer
    apiResultByte = apiVBResultByte(dllHandle, buf, result, setnr)
End Function

Function apiSetConfig(ByVal configName$, ByVal configValue$) As Integer
    apiSetConfig = apiVBSetConfig(dllHandle, configName, configValue)
End Function

Function apiState() As Integer
    apiState = apiVBState(dllHandle)
End Function

Function apiStateExt(ByVal ms&) As Integer
    apiStateExt = apiVBStateExt(dllHandle,ms)
End Function

Function apiSwitchDevice(ByVal deviceConnection$, ByVal deviceApplication$) As Integer
    apiSwitchDevice = apiVBSwitchDevice(dllHandle, deviceConnection, deviceApplication)
End Function

Sub apiTrace(ByVal msg$)
    If Len(msg) = 0 Then
        msg = ""        ' necessary because of VB bug
    End If
    Call apiVBTrace(dllHandle, msg)
End Sub

Sub closeServer()
    Call closeServerVB
End Sub

Function enableServer(ByVal onOff As Boolean) As Boolean
    enableServer = enableServerVB(onOff)
End Function

Function enableMultiThreading(ByVal onOff As Boolean) As Boolean
    enableMultiThreading = enableMultiThreadingVB(onOff)
End Function
