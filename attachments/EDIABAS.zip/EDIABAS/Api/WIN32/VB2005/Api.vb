'///
'///    api.bas
'///
'///    Comment       Visual Basic 8.0 (VB2005) Interface of EDIABAS for .NET
'///
'////////////////////////////////////////////////////////////////////////////////
Option Explicit
Imports Ediabas

' Optional: API Helper class for VB.NET
Public Class API : Inherits APIVB

    ' Types:

    ' VB Type of APIBOOL = Boolean
    ' VB Type of APICHAR = Byte
    ' VB Type of APIBYTE = Byte
    ' VB Type of APIINTEGER = Short
    ' VB Type of APIWORD = Integer
    ' VB Type of APILONG = Integer
    ' VB Type of APIDWORD = Long
    ' VB Type of APITEXT[] = String
    ' VB Type of APIBINARY[] = Array of Byte
    ' VB Type of APIREAL = Double
    ' VB Type of APIRESULTFIELD = API.APIRESULTFIELD

    ' Procedures and functions:

    ' Function apiInit As Boolean
    ' Function apiInitExt (ByVal device As String, ByVal devConnection As String, ByVal devApplication As String, ByVal reserved As String) As Boolean
    ' Sub apiEnd
    ' Function apiSwitchDevice (ByVal deviceConnection As String, ByVal deviceApplication As String) As Boolean
    ' Sub apiJob (ByVal ecu As String, ByVal job As String, ByVal para As String, ByVal result As String)
    ' Sub apiJobData (ByVal ecu As String, ByVal job As String, ByVal parabuf() As Byte, ByVal paralen As Integer, ByVal result As String)
    ' Sub apiJobExt (ByVal ecu As String, ByVal job As String, ByVal stdparabuf() As Byte, ByVal stdparalen As Integer, ByVal parabuf() As Byte, ByVal paralen As Integer, ByVal result As String, ByVal reserved As Integer)
    ' Function apiJobInfo (ByRef infoText As String) as Integer
    ' Function apiResultChar (ByRef buf As Byte, ByVal result As String, ByVal setnr As Integer) As Boolean
    ' Function apiResultByte (ByRef buf As Byte, ByVal result As String, ByVal setnr As Integer) As Boolean
    ' Function apiResultInt (ByRef buf As Short, ByVal result As String, ByVal setnr As Integer) As Boolean
    ' Function apiResultWord (ByRef buf As Integer, ByVal result As String, ByVal setnr As Integer) As Boolean
    ' Function apiResultLong (ByRef buf As Integer, ByVal result As String, ByVal setnr As Integer) As Boolean
    ' Function apiResultDWord (ByRef buf As Long, ByVal result As String, ByVal setnr As Integer) As Boolean
    ' Function apiResultReal (ByRef buf As Double, ByVal result As String, ByVal setnr As Integer) As Boolean
    ' Function apiResultText (ByRef buf As String, ByVal result As String, ByVal setnr As Integer, ByVal formatspec As String) As Boolean
    ' Function apiResultBinary (ByRef buf() as byte, ByRef buflen As Integer, ByVal result As String, ByVal setnr As Integer) As Boolean
    ' Function apiResultBinaryExt (ByRef buf() as byte, ByRef buflen As Integer, ByVal bufsize as Integer, ByVal result As String, ByVal setnr As Integer) As Boolean
    ' Function apiResultFormat (ByRef buf As Integer, ByVal result As String, ByVal setnr As Integer) As Boolean
    ' Function apiResultNumber (ByRef buf As Integer, ByVal setnr As Integer) As Boolean
    ' Function apiResultName (ByRef buf As String, ByVal index As Integer, ByVal setnr As Integer) As Boolean
    ' Function apiResultSets (ByRef sets As Integer) As Boolean
    ' Function apiResultVar (ByRef ecu As String) As Boolean
    ' Function apiResultsNew As API.APIRESULTFIELD
    ' Sub apiResultsScope (ByVal field As API.APIRESULTFIELD)
    ' Sub apiResultsDelete (ByVal field As API.APIRESULTFIELD)
    ' Function apiState As Integer
    ' Sub apiBreak
    ' Function apiErrorCode As Integer
    ' Function apiErrorText As String
    ' Function apiSetConfig (ByVal configName As String, ByVal configValue As String) As Boolean
    ' Function apiGetConfig (ByVal configName As String, ByRef configValue As String) As Boolean
    ' Sub closeServer
    ' Function enableServer (ByVal onOff As Boolean) As Boolean
    ' Function enableMultiThreading (ByVal onOff As Boolean) As Boolean

    ' NOT supported procedures and functions:
    '          apiErrorHandler
    '          apiCallBack

    Public Shared Shadows Sub apiBreak()
        Call APIVB.apiBreak()
    End Sub

    Public Shared Shadows Sub apiEnd()
        Call APIVB.apiEnd()
    End Sub

    Public Shared Shadows Function apiErrorCode() As Integer
        apiErrorCode = APIVB.apiErrorCode()
    End Function

    Public Shared Shadows Function apiErrorText() As String
        apiErrorText = APIVB.apiErrorText()
    End Function

    Public Shared Shadows Function apiGetConfig(ByVal configName As String, ByRef configValue As String) As Boolean
        apiGetConfig = APIVB.apiGetConfig(configName, configValue)
    End Function

    Public Shared Shadows Function apiInit() As Boolean
        apiInit = APIVB.apiInit()
    End Function

    Public Shared Shadows Function apiInitExt(ByVal device As String, ByVal devConnection As String, ByVal devApplication$, ByVal reserved As String) As Boolean
        apiInitExt = APIVB.apiInitExt(device, devConnection, devApplication, reserved)
    End Function

    Public Shared Shadows Sub apiJob(ByVal ecu As String, ByVal job As String, ByVal para As String, ByVal result As String)
        Call APIVB.apiJob(ecu, job, para, result)
    End Sub

    Public Shared Shadows Sub apiJobData(ByVal ecu As String, ByVal job As String, ByVal parabuf() As Byte, ByVal paralen As Integer, ByVal result As String)
        Call APIVB.apiJobData(ecu, job, parabuf, paralen, result)
    End Sub

    Public Shared Shadows Sub apiJobExt(ByVal ecu As String, ByVal job As String, ByVal stdparabuf() As Byte, ByVal stdparalen As Integer, ByVal parabuf() As Byte, ByVal paralen As Integer, ByVal result As String, ByVal reserved As Integer)
        Call APIVB.apiJobExt(ecu, job, stdparabuf, stdparalen, parabuf, paralen, result, reserved)
    End Sub

    Public Shared Shadows Function apiJobInfo(ByRef info As String) As Integer
        apiJobInfo = APIVB.apiJobInfo(info)
    End Function

    Public Shared Shadows Function apiResultBinary(ByRef buf() As Byte, ByRef buflen As Integer, ByVal result As String, ByVal setnr As Integer) As Boolean
        apiResultBinary = APIVB.apiResultBinary(buf, buflen, result, setnr)
    End Function

    Public Shared Shadows Function apiResultBinaryExt(ByRef buf() As Byte, ByRef buflen As Integer, ByVal bufsize As Integer, ByVal result As String, ByVal setnr As Integer) As Boolean
        apiResultBinaryExt = APIVB.apiResultBinaryExt(buf, buflen, bufsize, result, setnr)
    End Function

    Public Shared Shadows Function apiResultDWord(ByRef buf As Long, ByVal result As String, ByVal setnr As Integer) As Boolean
        apiResultDWord = APIVB.apiResultDWord(buf, result, setnr)
    End Function

    Public Shared Shadows Function apiResultFormat(ByRef buf As Integer, ByVal result As String, ByVal setnr As Integer) As Boolean
        apiResultFormat = APIVB.apiResultFormat(buf, result, setnr)
    End Function

    Public Shared Shadows Function apiResultChar(ByRef buf As Byte, ByVal result As String, ByVal setnr As Integer) As Boolean
        apiResultChar = APIVB.apiResultChar(buf, result, setnr)
    End Function
    Public Shared Shadows Function apiResultInt(ByRef buf As Short, ByVal result As String, ByVal setnr As Integer) As Boolean
        apiResultInt = APIVB.apiResultInt(buf, result, setnr)
    End Function

    Public Shared Shadows Function apiResultLong(ByRef buf As Integer, ByVal result As String, ByVal setnr As Integer) As Boolean
        apiResultLong = APIVB.apiResultLong(buf, result, setnr)
    End Function

    Public Shared Shadows Function apiResultName(ByRef buf As String, ByVal index As Integer, ByVal setnr As Integer) As Boolean
        apiResultName = APIVB.apiResultName(buf, index, setnr)
    End Function

    Public Shared Shadows Function apiResultNumber(ByRef buf As Integer, ByVal setnr As Integer) As Boolean
        apiResultNumber = APIVB.apiResultNumber(buf, setnr)
    End Function

    Public Shared Shadows Function apiResultReal(ByRef buf As Double, ByVal result As String, ByVal setnr As Integer) As Boolean
        apiResultReal = APIVB.apiResultReal(buf, result, setnr)
    End Function

    Public Shared Shadows Sub apiResultsDelete(ByRef field As API.APIRESULTFIELD)
        Call APIVB.apiResultsDelete(field)
    End Sub

    Public Shared Shadows Function apiResultSets(ByRef sets As Integer) As Boolean
        apiResultSets = APIVB.apiResultSets(sets)
    End Function

    Public Shared Shadows Function apiResultsNew() As API.APIRESULTFIELD
        apiResultsNew = APIVB.apiResultsNew()
    End Function

    Public Shared Shadows Sub apiResultsScope(ByRef field As API.APIRESULTFIELD)
        Call APIVB.apiResultsScope(field)
    End Sub

    Public Shared Shadows Function apiResultText(ByRef buf As String, ByVal result As String, ByVal setnr As Integer, ByVal formatspec As String) As Boolean
        apiResultText = APIVB.apiResultText(buf, result, setnr, formatspec)
    End Function

    Public Shared Shadows Function apiResultVar(ByRef ecu As String) As Boolean
        apiResultVar = APIVB.apiResultVar(ecu)
    End Function

    Public Shared Shadows Function apiResultWord(ByRef buf As Integer, ByVal result As String, ByVal setnr As Integer) As Boolean
        apiResultWord = APIVB.apiResultWord(buf, result, setnr)
    End Function

    Public Shared Shadows Function apiResultByte(ByRef buf As Byte, ByVal result As String, ByVal setnr As Integer) As Boolean
        apiResultByte = APIVB.apiResultByte(buf, result, setnr)
    End Function

    Public Shared Shadows Function apiSetConfig(ByVal configName As String, ByVal configValue As String) As Boolean
        apiSetConfig = APIVB.apiSetConfig(configName, configValue)
    End Function

    Public Shared Shadows Function apiState() As Integer
        apiState = APIVB.apiState()
    End Function

    Public Shared Shadows Function apiSwitchDevice(ByVal deviceConnection As String, ByVal deviceApplication As String) As Boolean
        apiSwitchDevice = APIVB.apiSwitchDevice(deviceConnection, deviceApplication)
    End Function

    Public Shared Shadows Sub closeServer()
        Call APIVB.closeServer()
    End Sub

    Public Shared Shadows Function enableServer(ByVal onOff As Boolean) As Boolean
        enableServer = APIVB.enableServer(onOff)
    End Function

    Public Shared Shadows Function enableMultiThreading(ByVal onOff As Boolean) As Boolean
        enableMultiThreading = APIVB.enableMultiThreading(onOff)
    End Function

End Class
