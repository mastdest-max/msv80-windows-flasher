/*****************************************************************************
***
***    apicalls.c
*** 
***    C-Anbindung an API32.DLL/API64.DLL (EDIABAS fuer WIN32/WIN64)
***    und APICE.DLL (EDIABAS fuer WinCE) mit Abbildung der API-Schnittstelle.
***
***    Fuer den Link-Vorgang sind alle benoetigten DLL-Schnittstellenfunktionen
***    in der entsprechenden DEF-Datei zu importieren, z.B. API32/64/CE.DLL:
***         IMPORTS    api.__apiInit
***                    api.__apiEnd
***                    api.__apiJob
***
***
***    Allgemeines zur DLL-Schnittstelle von EDIABAS fuer Windows:
***    -----------------------------------------------------------
***
***    1. Typkonventionen:
***    Die DLL-Funktionen entsprechen dem Windows-Standard und zeigen deshalb
***    abweichende Typkonventionen zur normalen API-Schnittstelle 
***    
***    2. Namenskonventionen:
***    Um die normale API-Schnittstelle trotzdem abbilden zu koennen, beginnen
***    zur Unterscheidung der Funktionsnamen alle DLL-Funktionen mit doppeltem
***    Underscore (z.B. __apiInit).
***    
***    3. Applikations-Locking ueber Handle:
***    Die API-Schnittstellenfunktionen __apiInit/__apiInitExt vergeben als 
***    Ergebnis einen Handle vom Typ "unsigned int", welcher dann jeder anderen
***    API-Schnittstellenfunktion als 1. Parameter uebergeben werden muss.
***
***    4. Geaenderter Aufruf zur Ermittlung des Fehlertextes:
***    Da die Rueckgabe von C-Stringadressen zu Problemen bei anderen Windows-
***    Programmiersystemen fuehren koennen, ist die DLL-Schnittstellenfunktion
***    __apiErrorText anders wie bisher aufzurufen. Der DLL-Schnittstellen-
***    funktion ist eine Pufferadresse und die max. Anzahl zu kopierender
***    Zeichen (mit abschliessendem '\0') zu uebergeben. Der Fehlertext wird
***    dann in den entsprechenden Puffer kopiert. Liegt kein Fehler vor, so
***    wird ein Leer-String im Puffer abgelegt.
***
***    5. Keine Unterstuetzung von Callback/Error-Handler
***    Callback/Error-Handler koennen bei Direktzugriff via DLL-Schnittstelle
***    nicht bedient werden, die entsprechenden API-Funktionen fehlen deshalb.
***    Im MultiThreading-Modus duerfen die Callback/Error-Handler nicht
***    verwendet werden.
***
******************************************************************************/


/***** Include-Dateien *******************************************************/

#include <windows.h>

#include "api.h"
#include "apidll.h"


/***** Statische Variable ****************************************************/

/* DLL-Handle */
static HINSTANCE hDll;

#ifndef _WIN32_WCE
/* DLL-Locking */
static BOOL dllLockInitialized=FALSE;
static CRITICAL_SECTION dllLock;
#endif

/* Handle fuer DLL-Zugriff */
static unsigned int handle;

/* Thread-ID der (letzten) EDIABAS-Initialisierung */
static DWORD apiThreadId=0;

/* Callback-Handler (nur fuer Thread der letzten EDIABAS-Initialisierung gueltig) */
static APIBOOL (*callbackHandler)(void)=NULL;

/* fuer Error-Handler-Mechanismus (nur fuer Thread der letzten EDIABAS-Initialisierung gueltig) */
static void (*errorHandler)(void)=NULL;
static APIBOOL errorHandlerCalled=APIFALSE;


/***** Hilfsfunktionen *******************************************************/

#ifdef _WIN32_WCE
static APIBOOL loadApi(const TCHAR *dll)
#else
static APIBOOL loadApi(const char *dll)
#endif
{
    if (hDll!=NULL)
        return APITRUE;
    return ((hDll=LoadLibrary(dll))!=NULL);
}

static APIBOOL watchApi(APIBOOL functionOK)
{
    if (!functionOK)
        if (__apiErrorCode(handle)!=EDIABAS_ERR_NONE)
            if (apiThreadId==GetCurrentThreadId())
                if (!errorHandlerCalled && errorHandler!=NULL) {
                    (*errorHandler)();
                    errorHandlerCalled=APITRUE;
                }
    return functionOK;
}


static void initLock()
{
#ifndef _WIN32_WCE
    if (dllLockInitialized)
        return;
    InitializeCriticalSection(&dllLock);
    dllLockInitialized=TRUE;
#endif
}

static void lockApi()
{
#ifndef _WIN32_WCE
    initLock();
    EnterCriticalSection(&dllLock);
#endif
}

static void unlockApi()
{
#ifndef _WIN32_WCE
    LeaveCriticalSection(&dllLock);
#endif
}


/***** API-Funktionsabbildungen **********************************************/

APIBOOL apiCheckVersion(int versionCompatibility,char *versionInfo)
{
#ifdef  _WIN32_WCE
    const TCHAR *dll=_T("APICE.DLL");
#else
#ifdef  _WIN64
    const char *dll="API64.DLL";
#else
    const char *dll="API32.DLL";
#endif
#endif
    if (!loadApi(dll)) {
        /* DLL nicht verfuegbar */
        if (versionInfo!=NULL)
            *versionInfo='\0';
        return APIFALSE;
    }
#ifdef  _WIN32_WCE
    if (GetProcAddress(hDll,_T("__apiCheckVersion"))==NULL) {
#else
    if (GetProcAddress(hDll,"__apiCheckVersion")==NULL) {
#endif
        /* Version < 7.0.0: apiCheckVersion() nicht verfuegbar */
        if (versionInfo!=NULL)
            *versionInfo='\0';
        return APIFALSE;
    }
    return __apiCheckVersion(versionCompatibility,versionInfo);
}

APIBOOL apiInit(void)
{
    initLock();
    apiThreadId=GetCurrentThreadId();
    errorHandler=callbackHandler=NULL;
    errorHandlerCalled=APIFALSE;
    return watchApi(__apiInit(&handle));
}

APIBOOL apiInitExt(const char *device,const char *devConnection,const char *devApplication,const char *reserved)
{
    initLock();
    apiThreadId=GetCurrentThreadId();
    errorHandler=callbackHandler=NULL;
    errorHandlerCalled=APIFALSE;
    return watchApi(__apiInitExt(&handle,device,devConnection,devApplication,reserved));
}

void apiEnd(void)
{
    if (apiState()==APIBUSY) {
        apiBreak();
        watchApi(APIFALSE);
    }
    if (apiThreadId==GetCurrentThreadId())
        apiThreadId=0;
    __apiEnd(handle);
}

APIBOOL apiSwitchDevice(const char *connection,const char *application)
{
    return watchApi(__apiSwitchDevice(handle,connection,application));
}

void apiJob(const char *ecu,const char *job,const char *para,const char *result)
{
    DWORD threadId=GetCurrentThreadId();
    if (threadId==apiThreadId)
        errorHandlerCalled=APIFALSE;
    __apiJob(handle,ecu,job,para,result);
    if (threadId==apiThreadId)
        if (callbackHandler!=NULL)
            apiState();
    watchApi(APIFALSE);
}

void apiJobData(const char *ecu,const char *job,
                const unsigned char *parabuf,int paralen,const char *result)
{
    DWORD threadId=GetCurrentThreadId();
    if (threadId==apiThreadId)
        errorHandlerCalled=APIFALSE;
    __apiJobData(handle,ecu,job,parabuf,paralen,result);
    if (threadId==apiThreadId)
        if (callbackHandler!=NULL)
            apiState();
    watchApi(APIFALSE);
}

void apiJobExt(const char *ecu,const char *job,
               const unsigned char *stdparabuf,int stdparalen,
               const unsigned char *parabuf,int paralen,
               const char *result,long reserved)
{
    DWORD threadId=GetCurrentThreadId();
    if (threadId==apiThreadId)
        errorHandlerCalled=APIFALSE;
    __apiJobExt(handle,ecu,job,stdparabuf,stdparalen,parabuf,paralen,result,reserved);
    if (threadId==apiThreadId)
        if (callbackHandler!=NULL)
            apiState();
    watchApi(APIFALSE);
}

int apiJobInfo(char *infoText)
{
    int pos=__apiJobInfo(handle,infoText);
    watchApi(APIFALSE);
    return pos;
}

APIBOOL apiResultChar(APICHAR *buf,const char *result,APIWORD set)
{
    return watchApi(__apiResultChar(handle,buf,result,set));
}

APIBOOL apiResultByte(APIBYTE *buf,const char *result,APIWORD set)
{
    return watchApi(__apiResultByte(handle,buf,result,set));
}

APIBOOL apiResultInt(APIINTEGER *buf,const char *result,APIWORD set)
{
    return watchApi(__apiResultInt(handle,buf,result,set));
}

APIBOOL apiResultWord(APIWORD *buf,const char *result,APIWORD set)
{
    return watchApi(__apiResultWord(handle,buf,result,set));
}

APIBOOL apiResultLong(APILONG *buf,const char *result,APIWORD set)
{
    return watchApi(__apiResultLong(handle,buf,result,set));
}

APIBOOL apiResultDWord(APIDWORD *buf,const char *result,APIWORD set)
{
    return watchApi(__apiResultDWord(handle,buf,result,set));
}

APIBOOL apiResultReal(APIREAL *buf,const char *result,APIWORD set)
{
    return watchApi(__apiResultReal(handle,buf,result,set));
}

APIBOOL apiResultText(APITEXT *buf,const char *result,APIWORD set,const char *format)
{
    return watchApi(__apiResultText(handle,buf,result,set,format));
}

APIBOOL apiResultBinary(APIBINARY *buf,APIWORD *buflen,const char *result,APIWORD set)
{
    return watchApi(__apiResultBinary(handle,buf,buflen,result,set));
}

APIBOOL apiResultBinaryExt(APIBINARY *buf,APIDWORD *buflen,APIDWORD bufSize,const char *result,APIWORD set)
{
    return watchApi(__apiResultBinaryExt(handle,buf,buflen,bufSize,result,set));
}

APIBOOL apiResultFormat(APIRESULTFORMAT *buf,const char *result,APIWORD set)
{
    return watchApi(__apiResultFormat(handle,buf,result,set));
}

APIBOOL apiResultNumber(APIWORD *buf,APIWORD set)
{
    return watchApi(__apiResultNumber(handle,buf,set));
}

APIBOOL apiResultName(char *buf,APIWORD index,APIWORD set)
{
    return watchApi(__apiResultName(handle,buf,index,set));
}

APIBOOL apiResultSets(APIWORD *sets)
{
    return watchApi(__apiResultSets(handle,sets));
}

APIBOOL apiResultVar(APITEXT *ecu)
{
    return watchApi(__apiResultVar(handle,ecu));
}

APIRESULTFIELD apiResultsNew(void)
{
    APIRESULTFIELD field=__apiResultsNew(handle);
    watchApi(APIFALSE);
    return field;
}

void apiResultsScope(APIRESULTFIELD field)
{
    __apiResultsScope(handle,field);
    watchApi(APIFALSE);
}

void apiResultsDelete(APIRESULTFIELD field)
{
    __apiResultsDelete(handle,field);
    watchApi(APIFALSE);
}

int apiState(void)
{
    int jobState;

    if ((jobState=__apiState(handle))!=APIREADY) {
        if (apiThreadId==GetCurrentThreadId())
            if (callbackHandler!=NULL)
                if (jobState==APIBUSY)
                    if ((*callbackHandler)())
                        apiBreak();
        watchApi(APIFALSE);
    }

    return jobState;
}

int apiStateExt(int suspendTime)
{
    int jobState;

    if ((jobState=__apiStateExt(handle,suspendTime))!=APIREADY) {
        if (apiThreadId==GetCurrentThreadId())
            if (callbackHandler!=NULL)
                if (jobState==APIBUSY)
                    if ((*callbackHandler)())
                        apiBreak();
        watchApi(APIFALSE);
    }

    return jobState;
}

void apiBreak(void)
{
    __apiBreak(handle);
    watchApi(APIFALSE);
}

void apiCallBack(APIBOOL (*action)(void))
{
    if (apiThreadId==GetCurrentThreadId())
        callbackHandler=action;
}

void apiErrorHandler(void (*action)(void))
{
    if (apiThreadId==GetCurrentThreadId())
        errorHandler=action;
}

int apiErrorCode(void)
{
    return __apiErrorCode(handle);
}

const char *apiErrorText()
{
    static char textbuffer[256];
    
    lockApi();
    __apiErrorText(handle,textbuffer,sizeof(textbuffer));
    unlockApi();
    
    return ((*textbuffer)? textbuffer:NULL);
}

APIBOOL apiSetConfig(const char *configName,const char *configValue)
{
    return __apiSetConfig(handle,configName,configValue);
}

APIBOOL apiGetConfig(const char *configName,char *configValue)
{
    return __apiGetConfig(handle,configName,configValue);
}

void apiTrace(const char *msg)
{
    __apiTrace(handle,msg);
}


/*****************************************************************************/
